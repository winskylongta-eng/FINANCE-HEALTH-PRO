# Finance Health Pro — Android source project

Aplikasi pencatatan keuangan pribadi berbahasa Indonesia dengan desain minimalis.

## Fitur
- Catat pemasukan dan pengeluaran, kategori, tanggal, metode pembayaran, dan catatan.
- Dashboard saldo, total pemasukan/pengeluaran, rasio pengeluaran, dan indikator kesehatan finansial.
- Anggaran bulanan dan rincian pengeluaran per kategori.
- Target tabungan dengan penambahan saldo.
- Grafik arus kas enam bulan dan ringkasan bulanan.
- Hapus transaksi, ekspor CSV, backup/pemulihan JSON.
- Penyimpanan lokal di perangkat (offline-first).

## Membuat APK
1. Buka folder proyek ini di Android Studio versi terbaru.
2. Pastikan Android SDK Platform 35 dan JDK yang disarankan Android Studio terpasang.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
- Ini adalah source project Android yang siap dibuka dan dibangun di Android Studio, bukan file APK yang sudah dikompilasi.
- Data disimpan lokal pada penyimpanan WebView aplikasi. Menghapus data aplikasi dapat menghapus transaksi. Gunakan menu Data & Backup secara berkala.
- Aplikasi tidak terhubung ke bank, tidak membaca rekening, dan tidak melakukan pembayaran otomatis.
- Indikator kesehatan adalah estimasi sederhana, bukan nasihat keuangan profesional.


## Build APK dari HP menggunakan GitHub Actions (tanpa komputer)
1. Buat akun atau masuk ke GitHub melalui browser HP.
2. Buat repository baru, misalnya `finance-health-pro`.
3. Upload seluruh isi ZIP yang sudah diekstrak (termasuk folder tersembunyi `.github`).
4. Buka tab **Actions**, pilih **Build Finance Health Pro APK**, lalu tekan **Run workflow**.
5. Tunggu sampai proses selesai dengan status hijau.
6. Buka hasil workflow dan unduh artifact **Finance-Health-Pro-APK**.
7. Ekstrak artifact ZIP, lalu buka `app-debug.apk` untuk memasang aplikasi.

Catatan: GitHub Actions membangun APK debug. Saat pertama kali memasang, Android mungkin meminta izin **Install unknown apps** untuk browser atau aplikasi file manager yang digunakan.
